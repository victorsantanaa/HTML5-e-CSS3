<?php
    $nome = '';
    $email = '';
    $mensagem = '';
    $erroFormulario = '';
    if( isset($_POST['submit']) ){
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $mensagem = $_POST['mensagem'];
        if($nome != '' && $email != '' && $mensagem !=''){
            //utilizador preencheu corretamente

        }else{
            //utilizador nao preencheu todos os campos
            $erroFormulario = "Por favor verifique o preenchimento dos campos";
        }
    }
?>
<header class="pagina-cabecalho">
    <h1 class="pagina-cabecalho__titulo">Contatos</h1>
</header>
<section class="container pagina-conteudo">
    <p class="text-center">
        <b>Alguma dúvida deixe-nos uma mensagem para esclarecemos a sua dúvida.</b>
    </p>
    <form action="#" class="formulario" method="post">
        <?php if($erroFormulario != ''): ?>
        <div class="formulario__erro">
            <?php echo $erroFormulario ?>
        </div>
        <?php endif; ?>
        <div class="formulario__grupo formulario__grupo--coluna-esq">
            <label class="formulario__label" for="nome">Nome</label>
            <br>
            <input class="formulario__campo" type="text" name="nome" id="nome">
        </div>
        <div class="formulario__grupo formulario__grupo--coluna-dir">
            <label class="formulario__label" for="email">Email</label>
            <br>
            <input class="formulario__campo" type="email" name="email" id="email">
        </div>
        <div class="formulario__grupo">
            <label class="formulario__label" for="mensagem">Mensagem</label>
            <br>
            <textarea class="formulario__campo" type="text" name="mensagem" id="mensagem" cols="30" rows="10"></textarea>
        </div>
        <input type="submit" class="formulario__botao" value="Enviar" name="submit">
    </form>
</section>